//go:build windows

// Своё окно программы на Windows: окно Win32 + встроенный в Windows движок WebView2.
// Написано без cgo и без сторонних библиотек: WebView2 загружается из установленного
// в системе рантайма (EmbeddedBrowserWebView.dll), COM-вызовы идут через таблицы методов.
// Если что-то пошло не так, программа откроется в Edge в режиме приложения.
package main

import (
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

func init() { runtime.LockOSThread() } // окно и COM должны жить в главном потоке

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")

	pRegisterClassExW          = user32.NewProc("RegisterClassExW")
	pCreateWindowExW           = user32.NewProc("CreateWindowExW")
	pDefWindowProcW            = user32.NewProc("DefWindowProcW")
	pDestroyWindow             = user32.NewProc("DestroyWindow")
	pShowWindow                = user32.NewProc("ShowWindow")
	pUpdateWindow              = user32.NewProc("UpdateWindow")
	pGetMessageW               = user32.NewProc("GetMessageW")
	pTranslateMessage          = user32.NewProc("TranslateMessage")
	pDispatchMessageW          = user32.NewProc("DispatchMessageW")
	pPostQuitMessage           = user32.NewProc("PostQuitMessage")
	pGetClientRect             = user32.NewProc("GetClientRect")
	pLoadIconW                 = user32.NewProc("LoadIconW")
	pLoadCursorW               = user32.NewProc("LoadCursorW")
	pFindWindowW               = user32.NewProc("FindWindowW")
	pSetForegroundWindow       = user32.NewProc("SetForegroundWindow")
	pIsIconic                  = user32.NewProc("IsIconic")
	pSetProcessDpiAwarenessCtx = user32.NewProc("SetProcessDpiAwarenessContext")
	pGetDpiForSystem           = user32.NewProc("GetDpiForSystem")
	pGetModuleHandleW          = kernel32.NewProc("GetModuleHandleW")
	pCoInitializeEx            = ole32.NewProc("CoInitializeEx")
	pCreateSolidBrush          = gdi32.NewProc("CreateSolidBrush")
)

const (
	className       = "KartochkiWindow"
	wmDestroy       = 0x0002
	wmSize          = 0x0005
	wmSetFocus      = 0x0007
	swShow          = 5
	swRestore       = 9
	wsOverlappedWin = 0x00CF0000
	cwUseDefault    = 0x80000000
)

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type winMsg struct {
	hwnd     uintptr
	message  uint32
	wParam   uintptr
	lParam   uintptr
	time     uint32
	ptX, ptY int32
	lPrivate uint32
}

type winRect struct{ left, top, right, bottom int32 }

// COM-объект обработчика: указатель на таблицу методов + счётчик ссылок.
type comHandler struct {
	vtbl *[4]uintptr // QueryInterface, AddRef, Release, Invoke
}

var (
	hwnd       uintptr
	controller uintptr
	webview    uintptr
	failed     bool
	keepAlive  []any
)

func newHandler(invoke func(this, hr, obj uintptr) uintptr) *comHandler {
	vt := &[4]uintptr{
		syscall.NewCallback(func(this, riid, out uintptr) uintptr {
			*(*uintptr)(unsafe.Pointer(out)) = this
			return 0
		}),
		syscall.NewCallback(func(this uintptr) uintptr { return 1 }),
		syscall.NewCallback(func(this uintptr) uintptr { return 1 }),
		syscall.NewCallback(invoke),
	}
	h := &comHandler{vtbl: vt}
	keepAlive = append(keepAlive, h, vt)
	return h
}

// Вызов метода COM-объекта по номеру в таблице методов (0-2 — методы IUnknown).
func comCall(obj uintptr, index int, args ...uintptr) uintptr {
	vtbl := *(*uintptr)(unsafe.Pointer(obj))
	fn := *(*uintptr)(unsafe.Pointer(vtbl + uintptr(index)*unsafe.Sizeof(uintptr(0))))
	r, _, _ := syscall.SyscallN(fn, append([]uintptr{obj}, args...)...)
	return r
}

func utf16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

// Если программа уже открыта — показываем её окно.
func focusExisting() bool {
	h, _, _ := pFindWindowW.Call(uintptr(unsafe.Pointer(utf16(className))), 0)
	if h == 0 {
		return false
	}
	if r, _, _ := pIsIconic.Call(h); r != 0 {
		pShowWindow.Call(h, swRestore)
	}
	pSetForegroundWindow.Call(h)
	return true
}

// Ищем установленный в Windows рантайм WebView2 (самую новую версию).
func findWebView2() string {
	sub := map[string]string{"amd64": "x64", "arm64": "arm64", "386": "x86"}[runtime.GOARCH]
	best, bestVer := "", []int(nil)
	for _, root := range []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LocalAppData")} {
		if root == "" {
			continue
		}
		base := filepath.Join(root, "Microsoft", "EdgeWebView", "Application")
		entries, _ := os.ReadDir(base)
		for _, e := range entries {
			dll := filepath.Join(base, e.Name(), "EBWebView", sub, "EmbeddedBrowserWebView.dll")
			if !exists(dll) {
				continue
			}
			if v := parseVersion(e.Name()); v != nil && newer(v, bestVer) {
				best, bestVer = dll, v
			}
		}
	}
	return best
}

func parseVersion(s string) []int {
	var v []int
	for _, p := range strings.Split(s, ".") {
		n, err := strconv.Atoi(p)
		if err != nil {
			return nil
		}
		v = append(v, n)
	}
	return v
}

func newer(a, b []int) bool {
	for i := 0; i < len(a) && i < len(b); i++ {
		if a[i] != b[i] {
			return a[i] > b[i]
		}
	}
	return len(a) > len(b)
}

func resize() {
	if controller == 0 {
		return
	}
	var r winRect
	pGetClientRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
	comCall(controller, 6, uintptr(unsafe.Pointer(&r))) // put_Bounds
}

func wndProc(h, m, wp, lp uintptr) uintptr {
	switch m {
	case wmSize:
		resize()
	case wmSetFocus:
		if controller != 0 {
			comCall(controller, 12, 0) // MoveFocus(programmatic)
		}
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(h, m, wp, lp)
	return r
}

func nativeWindow(url, dir string) bool {
	// Если прошлый запуск своего окна упал — сразу открываемся через Edge.
	crashFlag := filepath.Join(dir, "window-starting")
	if exists(crashFlag) {
		_ = os.Remove(crashFlag)
		return false
	}
	dll := findWebView2()
	if dll == "" {
		return false
	}
	create := syscall.NewLazyDLL(dll).NewProc("CreateWebViewEnvironmentWithOptionsInternal")
	if create.Find() != nil {
		return false
	}

	if pSetProcessDpiAwarenessCtx.Find() == nil {
		pSetProcessDpiAwarenessCtx.Call(^uintptr(3)) // PER_MONITOR_AWARE_V2 (-4)
	}
	pCoInitializeEx.Call(0, 2) // COINIT_APARTMENTTHREADED

	hInst, _, _ := pGetModuleHandleW.Call(0)
	icon, _, _ := pLoadIconW.Call(hInst, 1)
	cursor, _, _ := pLoadCursorW.Call(0, 32512)
	brush, _, _ := pCreateSolidBrush.Call(0x00D8E6EF) // бежевый фон, пока грузится страница
	wc := wndClassEx{
		lpfnWndProc:   syscall.NewCallback(wndProc),
		hInstance:     hInst,
		hIcon:         icon,
		hIconSm:       icon,
		hCursor:       cursor,
		hbrBackground: brush,
		lpszClassName: utf16(className),
	}
	wc.cbSize = uint32(unsafe.Sizeof(wc))
	if r, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		return false
	}
	dpi := uintptr(96)
	if pGetDpiForSystem.Find() == nil {
		if d, _, _ := pGetDpiForSystem.Call(); d != 0 {
			dpi = d
		}
	}
	hwnd, _, _ = pCreateWindowExW.Call(0,
		uintptr(unsafe.Pointer(utf16(className))), uintptr(unsafe.Pointer(utf16("Карточки"))),
		wsOverlappedWin, cwUseDefault, cwUseDefault, 1100*dpi/96, 820*dpi/96, 0, 0, hInst, 0)
	if hwnd == 0 {
		return false
	}
	pShowWindow.Call(hwnd, swShow)
	pUpdateWindow.Call(hwnd)

	_ = os.WriteFile(crashFlag, []byte("1"), 0o644)

	ctrlDone := newHandler(func(this, hr, ctrl uintptr) uintptr {
		if uint32(hr) != 0 || ctrl == 0 {
			failed = true
			pPostQuitMessage.Call(0)
			return 0
		}
		controller = ctrl
		comCall(controller, 1) // AddRef: храним ссылку
		resize()
		comCall(controller, 4, 1)                                  // put_IsVisible(TRUE)
		comCall(controller, 25, uintptr(unsafe.Pointer(&webview))) // get_CoreWebView2
		if webview != 0 {
			comCall(webview, 5, uintptr(unsafe.Pointer(utf16(url)))) // Navigate
		}
		comCall(controller, 12, 0) // MoveFocus
		go func() { time.Sleep(4 * time.Second); _ = os.Remove(crashFlag) }()
		return 0
	})
	envDone := newHandler(func(this, hr, env uintptr) uintptr {
		if uint32(hr) != 0 || env == 0 {
			failed = true
			pPostQuitMessage.Call(0)
			return 0
		}
		comCall(env, 3, hwnd, uintptr(unsafe.Pointer(ctrlDone))) // CreateCoreWebView2Controller
		return 0
	})

	userData := filepath.Join(os.Getenv("LocalAppData"), appName, "WebView2")
	_ = os.MkdirAll(userData, 0o755)
	hr, _, _ := create.Call(1, 0, uintptr(unsafe.Pointer(utf16(userData))), 0, uintptr(unsafe.Pointer(envDone)))
	if uint32(hr) != 0 {
		failed = true
	}

	var m winMsg
	for !failed {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	_ = os.Remove(crashFlag)
	if failed {
		pDestroyWindow.Call(hwnd)
		return false
	}
	return true
}
