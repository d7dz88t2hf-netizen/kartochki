#!/bin/bash
# Пересборка «Карточек» для macOS и Windows. Нужен Go 1.22+ и llvm (llvm-lipo, llvm-windres).
set -e
cd "$(dirname "$0")"
mkdir -p dist
(cd res && llvm-windres --target=pe-x86-64 --codepage=65001 app.rc -O coff -o ../rsrc_windows_amd64.syso)
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w -H=windowsgui" -o "dist/Карточки.exe" .
GOOS=darwin  GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o dist/k-arm64 .
GOOS=darwin  GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-s -w" -o dist/k-amd64 .
A="dist/Карточки.app/Contents"; mkdir -p "$A/MacOS" "$A/Resources"
llvm-lipo -create dist/k-arm64 dist/k-amd64 -output "$A/MacOS/Kartochki"
cp res/icon.icns "$A/Resources/AppIcon.icns"; cp res/Info.plist "$A/Info.plist"
echo "Готово: dist/Карточки.app и dist/Карточки.exe"
