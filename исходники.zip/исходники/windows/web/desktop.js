/* Настольная версия: колоды хранятся в файле на диске */
(async () => {
  let data;
  try { data = await (await fetch('/api/data')).json(); } catch { return toast('Не удалось открыть файл с колодами'); }
  const body = () => JSON.stringify({ app: 'kartochki', version: 1, decks: S.decks, settings: S.settings });
  let timer, dirty = false;
  const push = () => {
    dirty = false;
    return fetch('/api/data', { method: 'PUT', body: body() })
      .then(r => { if (!r.ok) throw 0; })
      .catch(() => { dirty = true; toast('Не удалось сохранить. Программа закрылась? Запустите её снова.'); });
  };
  if (data && data.decks) {
    S.decks = data.decks;
    Object.assign(S.settings, data.settings || {});
    fixDecks(); applyTheme(); render();
  } else if (Object.keys(S.decks).length) push(); // перенос из браузера в файл
  window.afterSave = () => { dirty = true; clearTimeout(timer); timer = setTimeout(push, 30); };
  setInterval(() => fetch('/api/ping').catch(() => {}), 20000);
  addEventListener('pagehide', () => {
    if (dirty) navigator.sendBeacon('/api/data', body());
    navigator.sendBeacon('/api/bye');
  });
})();
