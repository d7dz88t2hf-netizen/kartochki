// Карточки — настольная программа для macOS и Windows.
// Внутри лежит веб-интерфейс; программа поднимает его на 127.0.0.1,
// хранит колоды в файле на диске и открывает окно без адресной строки.
package main

import (
	"embed"
	"encoding/json"
	"errors"
	"io"
	"io/fs"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"sync"
	"time"
)

//go:embed web
var webFiles embed.FS

const (
	appName   = "Kartochki"
	basePort  = 47821
	pingReply = "kartochki-ok"
)

var (
	mu       sync.Mutex
	lastSeen = time.Now()
	dataFile string
)

func main() {
	dir, err := os.UserConfigDir() // macOS: ~/Library/Application Support, Windows: %APPDATA%
	if err != nil {
		dir = "."
	}
	dir = filepath.Join(dir, appName)
	_ = os.MkdirAll(dir, 0o755)
	dataFile = filepath.Join(dir, "kartochki.json")

	// Уже запущена? Показываем её окно (Windows) или открываем ещё одно.
	if focusExisting() {
		return
	}
	if alreadyRunning(basePort) {
		openWindow("http://127.0.0.1:" + strconv.Itoa(basePort) + "/")
		return
	}
	ln, err := net.Listen("tcp", "127.0.0.1:"+strconv.Itoa(basePort))
	if err != nil {
		ln, err = net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			os.Exit(1)
		}
	}
	url := "http://" + ln.Addr().String() + "/"

	web, _ := fs.Sub(webFiles, "web")
	mux := http.NewServeMux()
	mux.Handle("/", noCache(http.FileServer(http.FS(web))))
	mux.HandleFunc("/api/ping", func(w http.ResponseWriter, r *http.Request) {
		touch()
		io.WriteString(w, pingReply)
	})
	mux.HandleFunc("/api/bye", func(w http.ResponseWriter, r *http.Request) {
		// окно закрыто: даём 6 секунд на перезагрузку страницы, потом выходим
		mu.Lock()
		lastSeen = time.Now().Add(-idleLimit + 6*time.Second)
		mu.Unlock()
	})
	mux.HandleFunc("/api/data", handleData)

	go func() { _ = http.Serve(ln, mux) }()

	// Своё окно программы (Windows: WebView2). Возвращает false, если не получилось.
	if nativeWindow(url, dir) {
		os.Exit(0)
	}
	// Запасной вариант: окно браузера в режиме приложения.
	go watchIdle()
	openWindow(url)
	select {}
}

const idleLimit = 3 * time.Minute

func touch() { mu.Lock(); lastSeen = time.Now(); mu.Unlock() }

// Программа закрывается сама, когда окно приложения закрыто.
func watchIdle() {
	start := time.Now()
	for range time.Tick(2 * time.Second) {
		mu.Lock()
		idle := time.Since(lastSeen)
		mu.Unlock()
		if time.Since(start) > 90*time.Second && idle > idleLimit {
			os.Exit(0)
		}
	}
}

func handleData(w http.ResponseWriter, r *http.Request) {
	touch()
	switch r.Method {
	case http.MethodGet:
		b, err := os.ReadFile(dataFile)
		if err != nil {
			b = []byte("{}")
		}
		w.Header().Set("Content-Type", "application/json")
		w.Write(b)
	case http.MethodPut, http.MethodPost:
		body, err := io.ReadAll(io.LimitReader(r.Body, 200<<20))
		if err != nil || !json.Valid(body) {
			http.Error(w, "bad data", http.StatusBadRequest)
			return
		}
		if err := saveAtomic(body); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	default:
		w.WriteHeader(http.StatusMethodNotAllowed)
	}
}

// Сохраняем через временный файл; предыдущую версию оставляем как .bak.
func saveAtomic(b []byte) error {
	mu.Lock()
	defer mu.Unlock()
	tmp := dataFile + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	if _, err := os.Stat(dataFile); err == nil {
		_ = os.Remove(dataFile + ".bak")
		_ = os.Rename(dataFile, dataFile+".bak")
	}
	return os.Rename(tmp, dataFile)
}

func noCache(h http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		h.ServeHTTP(w, r)
	})
}

func alreadyRunning(port int) bool {
	c := http.Client{Timeout: 700 * time.Millisecond}
	resp, err := c.Get("http://127.0.0.1:" + strconv.Itoa(port) + "/api/ping")
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(resp.Body)
	return string(b) == pingReply
}

// Открывает окно приложения: Chrome/Edge/Brave в режиме приложения,
// а если их нет — браузер по умолчанию.
func openWindow(url string) {
	app := "--app=" + url
	switch runtime.GOOS {
	case "darwin":
		for _, b := range []string{"Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium", "Arc"} {
			if exists("/Applications/"+b+".app") || exists(filepath.Join(os.Getenv("HOME"), "Applications", b+".app")) {
				if exec.Command("open", "-na", b, "--args", app, "--window-size=1100,820").Start() == nil {
					return
				}
			}
		}
		_ = exec.Command("open", url).Start()
	case "windows":
		for _, p := range winBrowsers() {
			if exists(p) {
				if exec.Command(p, app, "--window-size=1100,820").Start() == nil {
					return
				}
			}
		}
		_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	default:
		for _, b := range []string{"google-chrome", "chromium", "microsoft-edge"} {
			if exec.Command(b, app).Start() == nil {
				return
			}
		}
		_ = exec.Command("xdg-open", url).Start()
	}
}

func winBrowsers() []string {
	var out []string
	for _, root := range []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LocalAppData")} {
		if root == "" {
			continue
		}
		out = append(out,
			filepath.Join(root, `Microsoft\Edge\Application\msedge.exe`),
			filepath.Join(root, `Google\Chrome\Application\chrome.exe`),
			filepath.Join(root, `BraveSoftware\Brave-Browser\Application\brave.exe`))
	}
	return out
}

func exists(p string) bool {
	_, err := os.Stat(p)
	return !errors.Is(err, os.ErrNotExist) && err == nil
}
